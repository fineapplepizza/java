package ����;

public class Question7 {

	public static void main(String[] args) {
		

	}

}
